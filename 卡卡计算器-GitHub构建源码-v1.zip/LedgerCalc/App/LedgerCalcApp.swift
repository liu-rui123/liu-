import SwiftUI

@main
struct LedgerCalcApp: App {
    @StateObject private var store = CalculationStore()

    var body: some Scene {
        WindowGroup {
            CalculatorView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
        }
    }
}

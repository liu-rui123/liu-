import Foundation

struct CalculationLine: Codable, Identifiable, Equatable {
    var id: UUID
    let expression: String
    let result: String
    let completedAt: Date

    init(id: UUID = UUID(), expression: String, result: String, completedAt: Date = .now) {
        self.id = id
        self.expression = expression
        self.result = result
        self.completedAt = completedAt
    }

    var fullText: String { "\(expression) = \(result)" }
}

struct CalculationSession: Codable, Identifiable, Equatable {
    var id: UUID
    var name: String
    var lines: [CalculationLine]
    var createdAt: Date
    var updatedAt: Date

    init(id: UUID = UUID(), name: String = "", lines: [CalculationLine] = [], createdAt: Date = .now, updatedAt: Date = .now) {
        self.id = id
        self.name = name
        self.lines = lines
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }

    var finalResult: String { lines.last?.result ?? "—" }

    var suggestedName: String {
        "未命名计算 · \(createdAt.formatted(date: .abbreviated, time: .shortened))"
    }
}

struct CalculatorDraft: Codable, Equatable {
    var session: CalculationSession
    var expression: String
    var lastResult: String
    var startsNewExpression: Bool

    static var empty: CalculatorDraft {
        CalculatorDraft(session: CalculationSession(), expression: "", lastResult: "0", startsNewExpression: false)
    }
}

struct CalculatorStorage: Codable {
    var draft: CalculatorDraft
    var savedSessions: [CalculationSession]
}

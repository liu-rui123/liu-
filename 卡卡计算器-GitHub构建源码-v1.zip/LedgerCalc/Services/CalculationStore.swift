import Foundation
import Combine

@MainActor
final class CalculationStore: ObservableObject {
    @Published private(set) var draft: CalculatorDraft
    @Published private(set) var savedSessions: [CalculationSession]
    @Published var errorMessage: String?

    private let evaluator = ExpressionEvaluator()
    private let storageKey = "kaka.calculator.storage.v1"
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: storageKey), let storage = try? JSONDecoder().decode(CalculatorStorage.self, from: data) {
            draft = storage.draft
            savedSessions = storage.savedSessions
        } else {
            draft = .empty
            savedSessions = []
        }
    }

    var inputDisplay: String {
        errorMessage ?? (draft.expression.isEmpty ? draft.lastResult : prettyExpression(draft.expression))
    }

    func input(_ token: String) {
        errorMessage = nil
        if token.allSatisfy({ $0.isNumber }) || token == "." {
            if draft.startsNewExpression { draft.expression = ""; draft.startsNewExpression = false }
            if token == "." && currentNumberHasDecimal { return }
            if token == "." && (draft.expression.isEmpty || isOperator(draft.expression.last) || draft.expression.last == "(") {
                draft.expression += "0"
            }
            draft.expression += token
        } else if token == "(" {
            if draft.startsNewExpression { draft.expression = ""; draft.startsNewExpression = false }
            if let last = draft.expression.last, last.isNumber || last == ")" { draft.expression += "×" }
            draft.expression += "("
        } else if token == ")" {
            guard openParentheses > 0, let last = draft.expression.last, !(isOperator(last) || last == "(") else { return }
            draft.expression += ")"
        } else if token == "%" {
            guard let last = draft.expression.last, last.isNumber || last == ")" else { return }
            draft.expression += "%"
        } else {
            appendOperator(token)
        }
        persist()
    }

    func toggleSign() {
        errorMessage = nil
        if draft.startsNewExpression { draft.expression = draft.lastResult == "0" ? "-" : "-\(draft.lastResult)"; draft.startsNewExpression = false }
        else if let range = draft.expression.range(of: #"[0-9.]+$"#, options: .regularExpression) {
            let before = draft.expression[..<range.lowerBound]
            if before.last == "-" && (before.dropLast().last.map { isOperator($0) } ?? true || before.dropLast().last == "(") {
                draft.expression.removeSubrange(before.index(before.endIndex, offsetBy: -1)..<range.lowerBound)
            } else {
                draft.expression.insert("-", at: range.lowerBound)
            }
        } else if draft.expression.isEmpty {
            draft.expression = "-"
        }
        persist()
    }

    func backspace() {
        errorMessage = nil
        guard !draft.startsNewExpression else { return }
        _ = draft.expression.popLast()
        persist()
    }

    func clearInput() {
        errorMessage = nil
        draft.expression = ""
        draft.lastResult = "0"
        draft.startsNewExpression = false
        draft.session.lines.removeAll()
        draft.session.updatedAt = .now
        persist()
    }

    func evaluateCurrentExpression() {
        errorMessage = nil
        let raw = draft.expression
        do {
            let result = try evaluator.display(evaluator.evaluate(raw))
            let visibleExpression = prettyExpression(raw)
            draft.session.lines.append(CalculationLine(expression: visibleExpression, result: result))
            draft.session.updatedAt = .now
            draft.lastResult = result
            draft.expression = ""
            draft.startsNewExpression = true
            persist()
        } catch let error as LocalizedError {
            errorMessage = error.errorDescription ?? "算式有误"
        } catch {
            errorMessage = "算式有误"
        }
    }

    func addToolLine(expression: String, result: Decimal) {
        errorMessage = nil
        let formattedResult = evaluator.display(result)
        draft.session.lines.append(CalculationLine(expression: expression, result: formattedResult))
        draft.session.updatedAt = .now
        draft.lastResult = formattedResult
        draft.expression = ""
        draft.startsNewExpression = true
        persist()
    }

    func deleteDraftLine(_ line: CalculationLine) {
        draft.session.lines.removeAll { $0.id == line.id }
        draft.session.updatedAt = .now
        persist()
    }

    func startNewDraft() {
        draft = .empty
        errorMessage = nil
        persist()
    }

    func saveDraft(name: String) {
        guard !draft.session.lines.isEmpty else { return }
        var saved = draft.session
        saved.id = UUID()
        saved.name = name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? saved.suggestedName : name.trimmingCharacters(in: .whitespacesAndNewlines)
        saved.updatedAt = .now
        savedSessions.insert(saved, at: 0)
        persist()
    }

    func rename(_ session: CalculationSession, to name: String) {
        guard let index = savedSessions.firstIndex(where: { $0.id == session.id }) else { return }
        savedSessions[index].name = name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? savedSessions[index].suggestedName : name.trimmingCharacters(in: .whitespacesAndNewlines)
        savedSessions[index].updatedAt = .now
        persist()
    }

    func deleteSavedSession(_ session: CalculationSession) {
        savedSessions.removeAll { $0.id == session.id }
        persist()
    }

    private var currentNumberHasDecimal: Bool {
        let tail = draft.expression.split(whereSeparator: { isOperator($0) || $0 == "(" || $0 == ")" }).last ?? ""
        return tail.contains(".")
    }

    private var openParentheses: Int {
        draft.expression.reduce(into: 0) { count, character in
            if character == "(" { count += 1 }
            if character == ")" { count -= 1 }
        }
    }

    private func appendOperator(_ token: String) {
        let visible = token == "−" ? "−" : token
        if draft.startsNewExpression {
            draft.expression = draft.lastResult
            draft.startsNewExpression = false
        }
        guard !draft.expression.isEmpty else {
            if visible == "−" { draft.expression = "−" }
            return
        }
        if let last = draft.expression.last {
            if isOperator(last) {
                draft.expression.removeLast()
            } else if last == "(" {
                return
            }
        }
        draft.expression += visible
    }

    private func isOperator(_ character: Character?) -> Bool {
        guard let character else { return false }
        return "+−×÷".contains(character)
    }

    private func prettyExpression(_ raw: String) -> String {
        raw.replacingOccurrences(of: "×", with: " × ")
            .replacingOccurrences(of: "÷", with: " ÷ ")
            .replacingOccurrences(of: "+", with: " + ")
            .replacingOccurrences(of: "−", with: " − ")
    }

    private func persist() {
        let storage = CalculatorStorage(draft: draft, savedSessions: savedSessions)
        guard let data = try? JSONEncoder().encode(storage) else { return }
        defaults.set(data, forKey: storageKey)
    }
}

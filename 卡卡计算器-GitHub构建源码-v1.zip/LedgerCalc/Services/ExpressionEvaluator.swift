import Foundation

enum ExpressionError: LocalizedError, Equatable {
    case emptyExpression
    case invalidCharacter
    case invalidNumber
    case missingOperand
    case missingClosingParenthesis
    case divideByZero

    var errorDescription: String? {
        switch self {
        case .emptyExpression: return "请输入算式"
        case .invalidCharacter: return "算式含有无法识别的字符"
        case .invalidNumber: return "数字格式不正确"
        case .missingOperand: return "算式不完整"
        case .missingClosingParenthesis: return "缺少右括号"
        case .divideByZero: return "不能除以 0"
        }
    }
}

struct ExpressionEvaluator {
    func evaluate(_ rawExpression: String) throws -> Decimal {
        let normalized = rawExpression
            .replacingOccurrences(of: "×", with: "*")
            .replacingOccurrences(of: "÷", with: "/")
            .replacingOccurrences(of: "−", with: "-")
            .replacingOccurrences(of: " ", with: "")
        guard !normalized.isEmpty else { throw ExpressionError.emptyExpression }
        var parser = Parser(source: Array(normalized))
        let value = try parser.parseExpression()
        guard parser.isAtEnd else { throw ExpressionError.invalidCharacter }
        return value
    }

    func display(_ decimal: Decimal) -> String {
        let number = NSDecimalNumber(decimal: decimal)
        if number == .notANumber { return "错误" }
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.usesGroupingSeparator = false
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 10
        return formatter.string(from: number) ?? number.stringValue
    }

    private struct Parser {
        let source: [Character]
        var index = 0

        var isAtEnd: Bool { index >= source.count }
        var current: Character? { isAtEnd ? nil : source[index] }

        mutating func parseExpression() throws -> Decimal {
            var value = try parseTerm()
            while let token = current, token == "+" || token == "-" {
                index += 1
                let rhs = try parseTerm()
                value = token == "+" ? value + rhs : value - rhs
            }
            return value
        }

        mutating func parseTerm() throws -> Decimal {
            var value = try parseUnary()
            while let token = current, token == "*" || token == "/" {
                index += 1
                let rhs = try parseUnary()
                if token == "/" {
                    guard rhs != 0 else { throw ExpressionError.divideByZero }
                    value /= rhs
                } else {
                    value *= rhs
                }
            }
            return value
        }

        mutating func parseUnary() throws -> Decimal {
            if current == "+" { index += 1; return try parseUnary() }
            if current == "-" { index += 1; return -(try parseUnary()) }
            return try parsePostfix()
        }

        mutating func parsePostfix() throws -> Decimal {
            var value = try parsePrimary()
            while current == "%" {
                index += 1
                value /= 100
            }
            return value
        }

        mutating func parsePrimary() throws -> Decimal {
            if current == "(" {
                index += 1
                let value = try parseExpression()
                guard current == ")" else { throw ExpressionError.missingClosingParenthesis }
                index += 1
                return value
            }

            let start = index
            var dots = 0
            while let token = current, token.isNumber || token == "." {
                if token == "." { dots += 1 }
                index += 1
            }
            guard index > start else { throw ExpressionError.missingOperand }
            guard dots <= 1 else { throw ExpressionError.invalidNumber }
            let value = String(source[start..<index])
            guard value != ".", let decimal = Decimal(string: value, locale: Locale(identifier: "en_US_POSIX")) else {
                throw ExpressionError.invalidNumber
            }
            return decimal
        }
    }
}

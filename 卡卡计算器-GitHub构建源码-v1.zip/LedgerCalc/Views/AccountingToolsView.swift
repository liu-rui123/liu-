import SwiftUI

struct AccountingToolsView: View {
    @EnvironmentObject private var store: CalculationStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedTool: ToolKind = .discount
    @State private var amount = "100"
    @State private var rate = "10"
    @State private var conversionCategory: ConversionCategory = .length
    @State private var fromUnit = "厘米"
    @State private var toUnit = "米"

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("工具", selection: $selectedTool) {
                        ForEach(ToolKind.allCases) { tool in Label(tool.title, systemImage: tool.icon).tag(tool) }
                    }
                    .pickerStyle(.menu)
                }

                if selectedTool == .conversion {
                    conversionFields
                } else {
                    Section(selectedTool.amountLabel) {
                        TextField("金额", text: $amount).keyboardType(.decimalPad)
                    }
                    Section(selectedTool.rateLabel) {
                        TextField("百分比", text: $rate).keyboardType(.decimalPad)
                    }
                    Section("预览") { Text(previewText).font(.title3.weight(.bold)).foregroundStyle(AppTheme.orange) }
                }
            }
            .scrollContentBackground(.hidden)
            .background(AppTheme.graphite)
            .navigationTitle("算账工具")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("加入过程") { addResult(); dismiss() }
                        .disabled(computedResult == nil)
                }
            }
            .onChange(of: conversionCategory) { _ in
                fromUnit = conversionCategory.units[0]
                toUnit = conversionCategory.units[1]
            }
        }
    }

    private var conversionFields: some View {
        Group {
            Section("换算类型") {
                Picker("类型", selection: $conversionCategory) {
                    ForEach(ConversionCategory.allCases) { Text($0.title).tag($0) }
                }
                .pickerStyle(.segmented)
            }
            Section("数值") { TextField("数值", text: $amount).keyboardType(.decimalPad) }
            Section("单位") {
                Picker("从", selection: $fromUnit) { ForEach(conversionCategory.units, id: \.self) { Text($0) } }
                Picker("到", selection: $toUnit) { ForEach(conversionCategory.units, id: \.self) { Text($0) } }
            }
            Section("预览") { Text(previewText).font(.title3.weight(.bold)).foregroundStyle(AppTheme.orange) }
        }
    }

    private var inputAmount: Decimal? { Decimal(string: amount, locale: Locale(identifier: "en_US_POSIX")) }
    private var inputRate: Decimal? { Decimal(string: rate, locale: Locale(identifier: "en_US_POSIX")) }

    private var computedResult: Decimal? {
        guard let amount = inputAmount else { return nil }
        if selectedTool == .conversion {
            guard let from = conversionCategory.factor(for: fromUnit), let to = conversionCategory.factor(for: toUnit) else { return nil }
            return amount * from / to
        }
        guard let rate = inputRate else { return nil }
        switch selectedTool {
        case .discount: return amount * (1 - rate / 100)
        case .tax, .tip: return amount * (1 + rate / 100)
        case .conversion: return nil
        }
    }

    private var previewText: String {
        guard let result = computedResult else { return "请输入有效数值" }
        let output = ExpressionEvaluator().display(result)
        return selectedTool == .conversion ? "\(amount) \(fromUnit) = \(output) \(toUnit)" : "结果：\(output)"
    }

    private func addResult() {
        guard let result = computedResult else { return }
        if selectedTool == .conversion {
            store.addToolLine(expression: "\(amount) \(fromUnit) → \(toUnit)", result: result)
        } else {
            let sign = selectedTool == .discount ? "−" : "+"
            store.addToolLine(expression: "\(amount) × (1 \(sign) \(rate)%)", result: result)
        }
    }
}

private enum ToolKind: String, CaseIterable, Identifiable {
    case discount, tax, tip, conversion
    var id: String { rawValue }
    var title: String { switch self { case .discount: return "折扣"; case .tax: return "税率"; case .tip: return "小费"; case .conversion: return "单位换算" } }
    var icon: String { switch self { case .discount: return "tag"; case .tax: return "receipt"; case .tip: return "cup.and.saucer"; case .conversion: return "arrow.left.arrow.right" } }
    var amountLabel: String { self == .tax ? "未税金额" : "金额" }
    var rateLabel: String { self == .discount ? "折扣比例（%）" : self == .tax ? "税率（%）" : "小费比例（%）" }
}

private enum ConversionCategory: String, CaseIterable, Identifiable {
    case length, weight
    var id: String { rawValue }
    var title: String { self == .length ? "长度" : "重量" }
    var units: [String] { self == .length ? ["毫米", "厘米", "米", "千米"] : ["克", "千克"] }
    func factor(for unit: String) -> Decimal? {
        let factors: [String: Decimal] = self == .length
            ? ["毫米": 0.001, "厘米": 0.01, "米": 1, "千米": 1000]
            : ["克": 0.001, "千克": 1]
        return factors[unit]
    }
}

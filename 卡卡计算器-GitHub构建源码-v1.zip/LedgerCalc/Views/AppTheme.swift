import SwiftUI

enum AppTheme {
    static let graphite = Color(red: 0.055, green: 0.059, blue: 0.071)
    static let panel = Color(red: 0.105, green: 0.112, blue: 0.133)
    static let panelLight = Color(red: 0.158, green: 0.166, blue: 0.192)
    static let orange = Color(red: 1.0, green: 0.49, blue: 0.13)
    static let muted = Color.white.opacity(0.58)
}

extension View {
    func panelStyle() -> some View {
        padding(14)
            .background(AppTheme.panel, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    }
}

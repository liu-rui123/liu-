import SwiftUI

struct CalculatorView: View {
    @EnvironmentObject private var store: CalculationStore
    @State private var showProcess = false
    @State private var showTools = false
    @State private var showSave = false
    @State private var showRecords = false
    @State private var confirmNew = false

    var body: some View {
        NavigationStack {
            GeometryReader { proxy in
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        header
                        displayCard
                        processCard
                        toolStrip
                        CalculatorKeypad(
                            onInput: store.input,
                            onSign: store.toggleSign,
                            onClear: store.clearInput,
                            onBackspace: store.backspace,
                            onEquals: store.evaluateCurrentExpression
                        )
                        .frame(maxWidth: proxy.size.width > 700 ? 620 : .infinity)
                    }
                    .padding(.horizontal, proxy.size.width > 700 ? 36 : 18)
                    .padding(.bottom, 24)
                }
            }
            .background(AppTheme.graphite.ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showTools) { AccountingToolsView() }
            .sheet(isPresented: $showProcess) { ProcessSheet(lines: store.draft.session.lines, onDelete: store.deleteDraftLine) }
            .sheet(isPresented: $showSave) { SaveRecordSheet(defaultName: store.draft.session.suggestedName) { store.saveDraft(name: $0) } }
            .sheet(isPresented: $showRecords) { RecordsView() }
            .confirmationDialog("新建计算会清空当前未保存草稿", isPresented: $confirmNew, titleVisibility: .visible) {
                Button("新建计算", role: .destructive) { store.startNewDraft() }
                Button("取消", role: .cancel) {}
            } message: {
                Text("已保存的记录不会受影响。")
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image("BrandLogo")
                .resizable()
                .scaledToFill()
                .frame(width: 38, height: 38)
                .clipShape(Circle())
                .overlay(Circle().stroke(AppTheme.orange.opacity(0.8), lineWidth: 1))
            VStack(alignment: .leading, spacing: 2) {
                Text("卡卡计算器").font(.headline.weight(.bold))
                Text("本机保存 · 不丢算账过程").font(.caption).foregroundStyle(AppTheme.muted)
            }
            Spacer()
            Button { confirmNew = true } label: { Image(systemName: "plus") }
            Button { showSave = true } label: { Image(systemName: "bookmark") }
                .disabled(store.draft.session.lines.isEmpty)
            Button { showRecords = true } label: { Image(systemName: "clock.arrow.circlepath") }
        }
        .font(.title3.weight(.semibold))
        .foregroundStyle(.white)
        .buttonStyle(HeaderButtonStyle())
        .padding(.top, 8)
    }

    private var displayCard: some View {
        VStack(alignment: .trailing, spacing: 12) {
            HStack {
                Text(store.draft.expression.isEmpty ? "当前结果" : "正在计算")
                    .foregroundStyle(AppTheme.muted)
                    .font(.subheadline)
                Spacer()
                Text("草稿中 \(store.draft.session.lines.count) 条")
                    .font(.caption.weight(.medium))
                    .foregroundStyle(AppTheme.orange)
            }
            Text(store.inputDisplay)
                .font(.system(size: 42, weight: .bold, design: .rounded))
                .foregroundStyle(store.errorMessage == nil ? .white : .red)
                .lineLimit(2)
                .minimumScaleFactor(0.46)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .animation(.easeInOut(duration: 0.16), value: store.inputDisplay)
        }
        .panelStyle()
        .overlay(alignment: .bottomLeading) {
            Capsule().fill(AppTheme.orange).frame(width: 68, height: 4).padding(14)
        }
    }

    private var processCard: some View {
        Button { showProcess = true } label: {
            HStack(spacing: 12) {
                Image(systemName: "list.bullet.rectangle.portrait")
                    .foregroundStyle(AppTheme.orange)
                    .font(.title3)
                VStack(alignment: .leading, spacing: 3) {
                    Text("过程").font(.headline)
                    Text(store.draft.session.lines.last?.fullText ?? "按 = 后，完整算式会保存为一行")
                        .font(.caption)
                        .foregroundStyle(AppTheme.muted)
                        .lineLimit(1)
                }
                Spacer()
                Text("\(store.draft.session.lines.count)").font(.caption.weight(.bold)).foregroundStyle(AppTheme.orange)
                Image(systemName: "chevron.right").font(.caption.weight(.bold)).foregroundStyle(AppTheme.muted)
            }
        }
        .buttonStyle(.plain)
        .panelStyle()
    }

    private var toolStrip: some View {
        HStack(spacing: 10) {
            Label("算账工具", systemImage: "wand.and.stars")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(AppTheme.orange)
            Spacer()
            Button("折扣 · 税率 · 小费 · 换算") { showTools = true }
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white)
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(AppTheme.panelLight, in: Capsule())
        }
    }
}

private struct HeaderButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(width: 38, height: 38)
            .background(AppTheme.panelLight.opacity(configuration.isPressed ? 0.55 : 1), in: Circle())
    }
}

struct CalculatorKeypad: View {
    let onInput: (String) -> Void
    let onSign: () -> Void
    let onClear: () -> Void
    let onBackspace: () -> Void
    let onEquals: () -> Void

    var body: some View {
        VStack(spacing: 10) {
            row([(.text("("), 1), (.text(")"), 1), (.clear, 1), (.backspace, 1)])
            row([(.text("7"), 1), (.text("8"), 1), (.text("9"), 1), (.text("÷"), 1)])
            row([(.text("4"), 1), (.text("5"), 1), (.text("6"), 1), (.text("×"), 1)])
            row([(.text("1"), 1), (.text("2"), 1), (.text("3"), 1), (.text("−"), 1)])
            row([(.sign, 1), (.text("0"), 1), (.text("."), 1), (.text("+"), 1)])
            row([(.text("%"), 1), (.equals, 3)])
        }
    }

    @ViewBuilder private func row(_ keys: [(CalculatorKey, Int)]) -> some View {
        HStack(spacing: 10) {
            ForEach(Array(keys.enumerated()), id: \.offset) { _, item in
                key(item.0)
                    .frame(maxWidth: .infinity)
                    .layoutPriority(Double(item.1))
            }
        }
    }

    private func key(_ key: CalculatorKey) -> some View {
        Button {
            switch key {
            case .text(let value): onInput(value)
            case .sign: onSign()
            case .clear: onClear()
            case .backspace: onBackspace()
            case .equals: onEquals()
            }
        } label: {
            Group {
                if key == .backspace { Image(systemName: "delete.left") }
                else { Text(key.label) }
            }
            .font(.system(size: 22, weight: .semibold, design: .rounded))
            .foregroundStyle(key.isAccent ? AppTheme.graphite : .white)
            .frame(maxWidth: .infinity, minHeight: 57)
            .background(key.isAccent ? AppTheme.orange : AppTheme.panelLight, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

enum CalculatorKey: Equatable {
    case text(String), sign, clear, backspace, equals
    var label: String {
        switch self {
        case .text(let value): return value
        case .sign: return "±"
        case .clear: return "AC"
        case .backspace: return ""
        case .equals: return "="
        }
    }
    var isAccent: Bool { self == .equals || (label == "+" || label == "−" || label == "×" || label == "÷") }
}

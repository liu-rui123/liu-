import SwiftUI
import UIKit

struct ProcessSheet: View {
    let lines: [CalculationLine]
    let onDelete: (CalculationLine) -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if lines.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "text.line.first.and.arrowtriangle.forward").font(.largeTitle).foregroundStyle(AppTheme.orange)
                        Text("还没有过程").font(.headline)
                        Text("完成一条算式后，会在这里显示完整表达式和结果。")
                            .font(.subheadline).foregroundStyle(.secondary).multilineTextAlignment(.center)
                    }
                    .padding()
                } else {
                    List {
                        ForEach(lines.reversed()) { line in
                            VStack(alignment: .leading, spacing: 8) {
                                Text(line.fullText).font(.body.weight(.semibold)).textSelection(.enabled)
                                HStack {
                                    Text(line.completedAt.formatted(date: .omitted, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                                    Spacer()
                                    Button { UIPasteboard.general.string = line.fullText } label: { Image(systemName: "doc.on.doc") }
                                        .buttonStyle(.borderless)
                                    Button(role: .destructive) { onDelete(line) } label: { Image(systemName: "trash") }
                                        .buttonStyle(.borderless)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle("本次计算过程")
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("完成") { dismiss() } } }
        }
    }
}

struct SaveRecordSheet: View {
    let defaultName: String
    let onSave: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("记录名称") {
                    TextField("未命名计算", text: $name)
                }
                Section {
                    Text("保存的是本次草稿的完整过程和最终结果；草稿仍会留在首页，方便你继续算。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("保存记录")
            .onAppear { if name.isEmpty { name = defaultName } }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") { onSave(name); dismiss() }
                }
            }
        }
    }
}

import SwiftUI
import UIKit

struct RecordsView: View {
    @EnvironmentObject private var store: CalculationStore
    @Environment(\.dismiss) private var dismiss
    @State private var searchText = ""
    @State private var selection: UUID?

    private var records: [CalculationSession] {
        let sorted = store.savedSessions.sorted { $0.updatedAt > $1.updatedAt }
        guard !searchText.isEmpty else { return sorted }
        return sorted.filter { $0.name.localizedCaseInsensitiveContains(searchText) || $0.lines.contains { $0.fullText.localizedCaseInsensitiveContains(searchText) } }
    }

    var body: some View {
        NavigationSplitView {
            List(selection: $selection) {
                if records.isEmpty {
                    Text(searchText.isEmpty ? "还没有已保存记录" : "没有匹配的记录")
                        .foregroundStyle(.secondary)
                }
                ForEach(records) { record in
                    NavigationLink(value: record.id) { RecordRow(record: record) }
                        .tag(record.id)
                        .contextMenu {
                            Button(role: .destructive) { store.deleteSavedSession(record) } label: { Label("删除", systemImage: "trash") }
                        }
                }
                .onDelete { offsets in
                    for offset in offsets { store.deleteSavedSession(records[offset]) }
                }
            }
            .navigationTitle("记录")
            .searchable(text: $searchText, prompt: "搜索名称或算式")
            .navigationDestination(for: UUID.self) { identifier in
                if let record = store.savedSessions.first(where: { $0.id == identifier }) {
                    RecordDetailView(record: record)
                }
            }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("关闭") { dismiss() } }
            }
        } detail: {
            if let selection, let record = store.savedSessions.first(where: { $0.id == selection }) {
                RecordDetailView(record: record)
            } else {
                VStack(spacing: 12) {
                    Image(systemName: "book.closed").font(.largeTitle).foregroundStyle(AppTheme.orange)
                    Text("选择一条记录查看完整过程").foregroundStyle(.secondary)
                }
            }
        }
        .onChange(of: records.map(\.id)) { ids in
            if let selection, !ids.contains(selection) { self.selection = nil }
        }
    }
}

private struct RecordRow: View {
    let record: CalculationSession
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(record.name).font(.headline).lineLimit(1)
            Text(record.lines.last?.fullText ?? "空记录").font(.caption).foregroundStyle(.secondary).lineLimit(1)
            HStack {
                Text(record.updatedAt.formatted(date: .abbreviated, time: .shortened)).font(.caption2).foregroundStyle(.secondary)
                Spacer()
                Text(record.finalResult).font(.caption.weight(.bold)).foregroundStyle(AppTheme.orange)
            }
        }
        .padding(.vertical, 3)
    }
}

struct RecordDetailView: View {
    @EnvironmentObject private var store: CalculationStore
    let record: CalculationSession
    @State private var showRename = false
    @State private var name = ""

    var body: some View {
        List {
            Section {
                VStack(alignment: .leading, spacing: 8) {
                    Text(record.name).font(.title2.weight(.bold))
                    Text("最终结果  \(record.finalResult)").font(.title3.weight(.semibold)).foregroundStyle(AppTheme.orange)
                    Text("更新于 \(record.updatedAt.formatted(date: .complete, time: .shortened))").font(.caption).foregroundStyle(.secondary)
                }
                .padding(.vertical, 6)
            }
            Section("完整过程（\(record.lines.count) 条）") {
                ForEach(record.lines) { line in
                    VStack(alignment: .leading, spacing: 5) {
                        Text(line.fullText).font(.body.weight(.medium)).textSelection(.enabled)
                        Text(line.completedAt.formatted(date: .omitted, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 3)
                }
            }
            Section {
                Button { UIPasteboard.general.string = record.finalResult } label: { Label("复制最终结果", systemImage: "doc.on.doc") }
                Button { UIPasteboard.general.string = record.lines.map(\.fullText).joined(separator: "\n") } label: { Label("复制完整过程", systemImage: "document.on.document") }
                Button { name = record.name; showRename = true } label: { Label("修改名称", systemImage: "pencil") }
                Button(role: .destructive) { store.deleteSavedSession(record) } label: { Label("删除这条记录", systemImage: "trash") }
            }
        }
        .navigationTitle("记录详情")
        .navigationBarTitleDisplayMode(.inline)
        .alert("修改记录名称", isPresented: $showRename) {
            TextField("记录名称", text: $name)
            Button("取消", role: .cancel) {}
            Button("保存") { store.rename(record, to: name) }
        }
    }
}

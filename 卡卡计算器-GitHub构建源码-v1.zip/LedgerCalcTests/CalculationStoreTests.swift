import XCTest
@testable import KakaCalculator

@MainActor
final class CalculationStoreTests: XCTestCase {
    private var defaults: UserDefaults!

    override func setUp() {
        super.setUp()
        defaults = UserDefaults(suiteName: "CalculationStoreTests")!
        defaults.removePersistentDomain(forName: "CalculationStoreTests")
    }

    func testEqualAddsOneCompleteLineAndNewStartsFreshDraft() {
        let store = CalculationStore(defaults: defaults)
        store.input("1"); store.input("+"); store.input("1"); store.input("+"); store.input("6")
        store.evaluateCurrentExpression()
        XCTAssertEqual(store.draft.session.lines.count, 1)
        XCTAssertEqual(store.draft.session.lines.first?.fullText, "1 + 1 + 6 = 8")
        store.startNewDraft()
        XCTAssertTrue(store.draft.session.lines.isEmpty)
    }

    func testDraftAndNamedRecordPersistLocally() {
        let store = CalculationStore(defaults: defaults)
        store.input("2"); store.input("+"); store.input("3"); store.evaluateCurrentExpression()
        store.saveDraft(name: "晚餐")
        let restored = CalculationStore(defaults: defaults)
        XCTAssertEqual(restored.draft.session.lines.first?.result, "5")
        XCTAssertEqual(restored.savedSessions.first?.name, "晚餐")
    }

    func testClearResetsCurrentDraftProcessButKeepsSavedRecords() {
        let store = CalculationStore(defaults: defaults)
        store.input("2"); store.input("+"); store.input("3"); store.evaluateCurrentExpression()
        store.saveDraft(name: "保留的记录")
        store.clearInput()
        XCTAssertTrue(store.draft.session.lines.isEmpty)
        XCTAssertEqual(store.inputDisplay, "0")
        XCTAssertEqual(store.savedSessions.first?.name, "保留的记录")
    }
}

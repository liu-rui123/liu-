import XCTest
@testable import KakaCalculator

final class ExpressionEvaluatorTests: XCTestCase {
    private let evaluator = ExpressionEvaluator()

    func testCompleteExpressionMakesOneCorrectResult() throws {
        XCTAssertEqual(evaluator.display(try evaluator.evaluate("1+1+6")), "8")
    }

    func testOperatorPrecedenceAndParentheses() throws {
        XCTAssertEqual(evaluator.display(try evaluator.evaluate("2+3*4")), "14")
        XCTAssertEqual(evaluator.display(try evaluator.evaluate("(2+3)*4")), "20")
    }

    func testPercentAndNegativeNumber() throws {
        XCTAssertEqual(evaluator.display(try evaluator.evaluate("50%")), "0.5")
        XCTAssertEqual(evaluator.display(try evaluator.evaluate("-3+5")), "2")
    }

    func testInvalidExpressionsThrowWithoutAResult() {
        XCTAssertThrowsError(try evaluator.evaluate("1/0")) { XCTAssertEqual($0 as? ExpressionError, .divideByZero) }
        XCTAssertThrowsError(try evaluator.evaluate("1+"))
    }
}

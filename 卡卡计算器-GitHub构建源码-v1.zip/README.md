# 卡卡计算器

面向 iPhone 和 iPad 的本地算账计算器。深石墨底色、暖橙操作键，完整保留每次按 `=` 的算式，例如 `1 + 1 + 6 = 8`。

## 已实现

- 四则、括号、小数、正负号、百分比、退格和连续计算。
- 折扣、税率、小费、长度/重量换算；工具结果可加入过程。
- 当前草稿自动保存；命名保存完整会话；搜索、改名、复制、删除记录。
- iPhone 的记录全屏列表与 iPad 的双栏详情布局。
- 全部数据只存在设备本机 `UserDefaults`，没有登录或云同步。

## GitHub 构建

仓库已包含 `.github/workflows/build-ios.yml`。推送源码到 `main` 后，打开 GitHub 的 **Actions → Build Kaka Calculator IPA**，完成后在 Artifacts 下载 `KakaCalculator-unsigned-IPA`。

若仓库里只能上传本目录生成的源码 ZIP，工作流会自动解压 `卡卡计算器-GitHub构建源码-v1.zip` 再构建。注意：GitHub 必须先已有本仓库的 workflow 文件；首次新建仓库时，请先解压上传一次所有文件，或先创建该 workflow 文件。

IPA 未签名，需用你自己的 Apple 开发者证书重签后安装到真机。
